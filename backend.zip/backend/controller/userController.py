# from main import app
# from model.userModel import userModel
# from flask import request,jsonify

# obj = userModel()

# # Login endpoint
# @app.route("/login", methods=['POST'])
# def login():
#     try:
#         data = request.get_json()
#         userid = data.get('name')
#         password = data.get('password')

#         user = User.validate_login(name, password)
#         obj.close_connection()
#         if user:
#             return jsonify({'message': 'Login successful!', 'name': user.name}), 200
#         else:
#             return jsonify({'message': 'Invalid userid or password'}), 401
#     except Exception as e:
#         print("Error:", e)
#         return jsonify({'message': 'An error occurred while processing your request!'}), 500