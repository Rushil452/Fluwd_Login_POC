# import mysql.connector

# class userModel():

#     def __init__(self):
#         # Connect to MySQL database
#         try:
#             self.conn = mysql.connector.connect(host="localhost",user="root",password="Zxcvbnm,./110",database="sys")
#             self.cursor = self.conn.cursor()
#         except:
#             print("Error: " + self.conn.Error())

#     def validateLogin(self,username, password):
#         try:

#             # Execute SQL query to fetch user data
#             self.cursor.execute("SELECT * FROM User WHERE name = %s AND password = %s", (username, password))
#             user_data = self.cursor.fetchone()

#             # Close database connection
#             self.cursor.close()
#             self.conn.close()

#             if user_data:
#                 return user_data
#         except Exception as e:
#             print("Error:", e)
#             return False

#     @staticmethod
#     def validate_login(name, password):
#         user = userModel.validateLogin(name,password)
#         if user:
#             return user
#         return None