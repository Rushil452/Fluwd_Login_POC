from flask import request,Flask,jsonify
import mysql.connector
import controller.userController as userController
from flask_cors import CORS

# MySQL Database Configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Zxcvbnm,./110',
    'database': 'sys'
}

app = Flask(__name__)
CORS(app)

@app.route('/login', methods=['POST'])
def validate_login():
    try:
        # Retrieve username and password from the request
        data = request.get_json()
        email = data['emailid']
        password = data['password']

        # Connect to MySQL database
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()

        # Execute SQL query to fetch user data
        cursor.execute("SELECT * FROM User WHERE email = %s AND password = %s", (email, password))
        user_data = cursor.fetchone()

        # Close database connection
        cursor.close()
        conn.close()

        if user_data:
            # User found, return success
            return jsonify ({'success': True, 'message': 'Login successful!', 'data': user_data})
        else:
            return jsonify({'success': False, 'error': 'Invalid username or password.'}), 401
    except Exception as e:
        print("Error:", e)
        return False

if __name__ == '__main__':
    app.run(debug=True)

